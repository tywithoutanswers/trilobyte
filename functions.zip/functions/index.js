// Import the necessary Firebase functions and Firebase Admin SDK
//const { onSchedule } = require("firebase-functions/v2/scheduler");
//const { logger } = require("firebase-functions");
//const admin = require("firebase-admin");
//admin.initializeApp();

// Firebase Firestore SDK (accessed via admin.firestore())
//const db = admin.firestore(); // Get Firestore instance

// OpenWeatherMap API Key and cities list
//const apiKey = 'c615463eef657dcc5b26617f1a3471ef'; // API key for OpenWeatherMap
//const cities = [
//  'Galway,ie', 'Cork,ie', 'Dublin,ie', 'Reykjavik,is', 'Brest,fr', 
//  'Lisbon,pt', 'Cardiff,uk', 'The Hague,nl'
//];

// Function to fetch weather data and upload to Firestore
//exports.saveWeatherData = onSchedule("* * * * *", async (event) => {
//  const fetchCount = 0;
//  const totalFetches = cities.length;
  
//  let weatherData = {};
  
  // Function to fetch weather data for a given city
//  const fetchWeatherData = async (city) => {
//    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}`;

//    try {
//      const response = await fetch(apiUrl);
//      if (!response.ok) {
//        throw new Error('API request failed with status ' + response.status);
//      }
//      const data = await response.json();
//      const currentTemperature = data.main.temp; // Temperature in Kelvin
//      const temperatureInCelsius = currentTemperature - 273.15; // Convert to Celsius
//      weatherData[city] = Math.round(temperatureInCelsius * 100) / 100;

      // If all weather data is fetched, upload it to Firestore
//      if (Object.keys(weatherData).length === totalFetches) {
//        await uploadWeatherData(weatherData);
//      }
//    } catch (error) {
//      logger.error(`Error fetching weather data for ${city}:`, error);
//    }
//  };

  // Function to upload the weather data to Firestore
//  const uploadWeatherData = async (weatherDataJson) => {
//    try {
//      const docRef = db.collection('weather').doc('weatherData'); // Correct Firestore reference
//      await docRef.set(weatherDataJson); // Upload data
//      logger.log('Document uploaded:', weatherDataJson);
//    } catch (error) {
//      logger.error('Error uploading weather data to Firestore:', error);
//    }
//  };

  // Fetch weather data for all cities
//  for (let city of cities) {
//    await fetchWeatherData(city);
//  }
//});
