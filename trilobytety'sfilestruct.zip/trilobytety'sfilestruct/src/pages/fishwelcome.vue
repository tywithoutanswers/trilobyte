<script setup>
</script>

<template>
    
<html>
<head>
<title>Welcome to Trilobyte Trawling!</title>
<link rel="stylesheet" href="fishstyle.css">
</head>
<body>
<div class="div1">   
<h1>Welcome to Trilobyte Trawling!</h1>
<h2>A browser fishing game developed by Trilobyte Studios</h2>
<a href="fishlogin.html">Login</a>
</div>
</body>   
</html>

</template>

<style scoped>
body{
    background-color:lightblue;

}
div{
    background-color:lawngreen;
    font-family:Arial, Helvetica, sans-serif;
    font-size:18px;
    text-align:center;
}
a{
    color:blue;
}
form{
    text-align:center;
    border-color:black;
    border-radius:4px;
    color:teal;
}
</style>
