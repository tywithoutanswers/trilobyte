<script setup>
import fishwelcome from './pages/fishwelcome.vue'
</script>

<template>
  <fishwelcome />
</template>

<style scoped>
</style>
