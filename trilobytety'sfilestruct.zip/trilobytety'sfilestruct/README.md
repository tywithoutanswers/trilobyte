# trilobyte
Setting up the project on a local repository

required Node.js

## Project Setup
```sh
npm install #to install dependencies like vite
```
## Local Test
```sh
npm run dev #to locally test without deploying to firebase
```
## Deploy to firebase
```sh
npm run build
firebase deploy --only hosting #deploy to firebase
```
